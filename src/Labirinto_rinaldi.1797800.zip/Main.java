public class Main
{
    public static void main(String[] args)
    {
        Labirinto labirinto = new Labirinto(3);
        labirinto.entraEGioca();
    }
}
