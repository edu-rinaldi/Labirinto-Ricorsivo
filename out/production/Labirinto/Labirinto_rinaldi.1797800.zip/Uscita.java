public class Uscita extends Corridoio
{
    /**
     * Costruttore classe uscita
     * @param corridoioPrecedente
     */
    public Uscita(Corridoio corridoioPrecedente)
    {
        super(corridoioPrecedente);
    }
}

